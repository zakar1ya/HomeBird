﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HomeBird.DataBase.Ef7.Models
{
    public class HbIncubators
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public string Title { get; set; }

        public bool IsDeleted { get; set; }
    }
}
