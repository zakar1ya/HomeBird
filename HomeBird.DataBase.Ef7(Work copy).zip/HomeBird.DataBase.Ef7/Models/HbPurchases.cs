﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace HomeBird.DataBase.Ef7.Models
{
    public class HbPurchases
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public DateTime PurchaseDate { get; set; }

        public int Count { get; set; }

        public decimal Amount { get; set; }

        public string Address { get; set; }
        
        public int LotId { get; set; }

        public bool IsDeleted { get; set; }

        [ForeignKey("LotId")]
        public HbLots Lot { get; set; }
    }
}
