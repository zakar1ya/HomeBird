﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;
using System.Text;

namespace HomeBird.DataBase.Ef7.Context
{
    public class HomeBirdContextFactory : IDbContextFactory<HomeBirdContext>
    {
        public HomeBirdContext Create(DbContextFactoryOptions options)
        {
            var optionsBuilder = new DbContextOptionsBuilder<HomeBirdContext>();
            optionsBuilder.UseSqlServer("Data Source=192.168.88.240, 1433;Initial Catalog=HomeBirds;User ID=dbMigratorHb;Password=passTest!#");

            return new HomeBirdContext(optionsBuilder.Options);
        }
    }
}
