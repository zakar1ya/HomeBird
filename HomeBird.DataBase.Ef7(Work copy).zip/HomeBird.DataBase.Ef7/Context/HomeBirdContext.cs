﻿using HomeBird.DataBase.Ef7.Models;
using Microsoft.EntityFrameworkCore;

namespace HomeBird.DataBase.Ef7.Context
{
    public class HomeBirdContext : DbContext
    {
        public DbSet<HbLots> Lots { get; set; }

        public DbSet<HbBroods> Broods { get; set; }

        public DbSet<HbIncubators> Incubators { get; set; }

        public DbSet<HbLayings> Layings { get; set; }

        public DbSet<HbOverheads> Overheads { get; set; }

        public DbSet<HbPurchases> Purchases { get; set; }

        public DbSet<HbSales> Sales { get; set; }

        public HomeBirdContext(DbContextOptions<HomeBirdContext> options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=192.168.88.240, 1433;Initial Catalog=HomeBirds;User ID=dbMigratorHb;Password=passTest!#");
        }
    }
}
